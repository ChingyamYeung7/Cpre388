package com.example.smartly.UI;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.smartly.R;
import com.example.smartly.model.ScoreEntry;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.List;

public class LeaderboardFragment extends Fragment {

    private ListView listLeaderboard;
    private FirebaseFirestore db;
    private ArrayAdapter<String> adapter;
    private List<String> items = new ArrayList<>();

    public LeaderboardFragment() {}

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_leaderboard, container, false);

        listLeaderboard = v.findViewById(R.id.listLeaderboard);
        Button btnRefresh = v.findViewById(R.id.btnRefreshLeaderboard);

        adapter = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_list_item_1, items);
        listLeaderboard.setAdapter(adapter);

        db = FirebaseFirestore.getInstance();

        btnRefresh.setOnClickListener(view -> loadScores());

        loadScores();
        return v;
    }

    
    private void loadScores() {
        items.clear();
        db.collection("scores")
                .orderBy("score", Query.Direction.DESCENDING)
                .limit(200)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {

                    java.util.HashMap<String, ScoreEntry> bestByKey = new java.util.HashMap<>();

                    for (com.google.firebase.firestore.QueryDocumentSnapshot doc : queryDocumentSnapshots) {

                        String uid = doc.getString("uid");
                        String name = doc.getString("name");
                        String email = doc.getString("email");
                        if (email == null) email = doc.getString("userEmail");

                        Long scoreL = doc.getLong("score");
                        int score = (scoreL != null) ? scoreL.intValue() : 0;


                        String key;
                        if (uid != null && !uid.trim().isEmpty()) {
                            key = "uid:" + uid.trim();
                        } else if (email != null && !email.trim().isEmpty()) {
                            key = "email:" + email.trim().toLowerCase();
                        } else {
                            key = "doc:" + doc.getId();
                        }

                        if (name == null || name.trim().isEmpty()) {

                            if (email != null && !email.trim().isEmpty()) name = email.trim();
                            else name = "Player";
                        } else {
                            name = name.trim();
                        }

                        ScoreEntry candidate = new ScoreEntry(uid, name, score);

                        ScoreEntry existing = bestByKey.get(key);
                        if (existing == null || candidate.score > existing.score) {
                            bestByKey.put(key, candidate);
                        }
                    }

                    java.util.ArrayList<ScoreEntry> sorted = new java.util.ArrayList<>(bestByKey.values());
                    java.util.Collections.sort(sorted, (a, b) -> Integer.compare(b.score, a.score));

                    for (ScoreEntry e : sorted) {
                        items.add(e.toString());
                    }

                    adapter.notifyDataSetChanged();
                })
                .addOnFailureListener(e -> {

                    adapter.notifyDataSetChanged();
                });
    }

}
