package com.example.smartly.UI;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.smartly.R;
import com.example.smartly.model.Course;
import com.example.smartly.model.Question;
import com.example.smartly.util.CourseRepository;
import com.example.smartly.util.QuestionRepository;

import java.util.ArrayList;
import java.util.List;

public class ReviewFragment extends Fragment {

    private static final String ARG_COURSE_ID = "course_id";
    private String courseId;

    public static ReviewFragment newInstance(String courseId) {
        ReviewFragment f = new ReviewFragment();
        Bundle b = new Bundle();
        b.putString(ARG_COURSE_ID, courseId);
        f.setArguments(b);
        return f;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            courseId = getArguments().getString(ARG_COURSE_ID);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_review, container, false);

        Button btnBack = v.findViewById(R.id.btnBack);
        TextView tvTitle = v.findViewById(R.id.tvTitle);
        LinearLayout list = v.findViewById(R.id.container);

        Course c = CourseRepository.getCourseById(courseId);
        tvTitle.setText((c != null ? c.title : "Review") + " ; Review");

        List<Question> qs = QuestionRepository.getQuestionsForCourse(courseId);
        if (qs == null) qs = new ArrayList<>();

        list.removeAllViews();
        int i = 1;
        for (Question q : qs) {
            View card = inflater.inflate(R.layout.item_review_card, list, false);

            TextView tvNum = card.findViewById(R.id.tvNum);
            TextView tvPrompt = card.findViewById(R.id.tvPrompt);
            TextView tvAnswer = card.findViewById(R.id.tvAnswer);
            TextView tvLesson = card.findViewById(R.id.tvLesson);

            tvNum.setText("Problem " + i);
            tvPrompt.setText(q.getPrompt());

            String correctText;
            if (q.getType() == Question.Type.MULTIPLE_CHOICE) {
                String[] opts = q.getOptions();
                int idx = q.getCorrectIndex();
                correctText = (opts != null && idx >= 0 && idx < opts.length) ? opts[idx] : "(answer unavailable)";
            } else {
                List<String> order = q.getCorrectOrder();
                correctText = (order != null) ? String.join(" , ", order) : "(answer unavailable)";
            }
            tvAnswer.setText("Correct answer: " + correctText);
            tvLesson.setText(q.getLesson());

            list.addView(card);
            i++;
        }

        btnBack.setOnClickListener(view -> {
            if (getActivity() instanceof com.example.smartly.MainActivity) {
                ((com.example.smartly.MainActivity) getActivity()).onBackPressed();
            }
        });

        return v;
    }
}
