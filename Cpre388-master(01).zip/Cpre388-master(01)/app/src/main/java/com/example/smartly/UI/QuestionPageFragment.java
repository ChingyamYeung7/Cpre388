package com.example.smartly.UI;

import android.content.ClipData;
import android.os.Bundle;
import android.os.Build;
import android.view.DragEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.smartly.GameState;
import com.example.smartly.MainActivity;
import com.example.smartly.R;
import com.example.smartly.model.Question;
import com.example.smartly.util.QuestionRepository;

import java.util.ArrayList;
import java.util.List;

/**
 * Displays a single question page (MCQ or Drag-Drop). Used inside ProblemSetFragment.
 */
public class QuestionPageFragment extends Fragment {

    private static final String ARG_COURSE_ID = "courseId";
    private static final String ARG_INDEX = "index";
    private static final int TOKENS_PER_CORRECT = 5;

    public interface Listener {
        void onAnswered(int index, boolean correct);
        void onRequestAdvance(int index);
    }

    private String courseId;
    private int index;

    private List<Question> questions = new ArrayList<>();
    private Question q;

    // Views
    private TextView tvExplanation, tvQuestion;
    private RadioGroup rgOptions;
    private RadioButton rbOption1, rbOption2, rbOption3;

    private View dragArea;
    private TextView tvDrag1, tvDrag2, tvDrag3;
    private TextView slot1, slot2, slot3;

    private Button btnCheck;
    private Button btnHint;
    private EditText etFeedback;
    private Button btnSubmitFeedback;

    private boolean answered = false;
    private boolean answeredCorrect = false;

    public static QuestionPageFragment newInstance(String courseId, int index) {
        QuestionPageFragment f = new QuestionPageFragment();
        Bundle b = new Bundle();
        b.putString(ARG_COURSE_ID, courseId);
        b.putInt(ARG_INDEX, index);
        f.setArguments(b);
        return f;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            courseId = getArguments().getString(ARG_COURSE_ID);
            index = getArguments().getInt(ARG_INDEX, 0);
        }

        questions = QuestionRepository.getQuestionsForCourse(courseId);
        if (questions == null) questions = new ArrayList<>();
        if (index < 0) index = 0;
        if (index >= questions.size()) index = Math.max(0, questions.size() - 1);

        if (!questions.isEmpty()) q = questions.get(index);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_question_page, container, false);

        tvExplanation = v.findViewById(R.id.tvExplanation);
        tvQuestion    = v.findViewById(R.id.tvQuestion);
        rgOptions     = v.findViewById(R.id.rgOptions);
        rbOption1     = v.findViewById(R.id.rbOption1);
        rbOption2     = v.findViewById(R.id.rbOption2);
        rbOption3     = v.findViewById(R.id.rbOption3);

        dragArea = v.findViewById(R.id.dragArea);
        tvDrag1  = v.findViewById(R.id.tvDrag1);
        tvDrag2  = v.findViewById(R.id.tvDrag2);
        tvDrag3  = v.findViewById(R.id.tvDrag3);
        slot1    = v.findViewById(R.id.slot1);
        slot2    = v.findViewById(R.id.slot2);
        slot3    = v.findViewById(R.id.slot3);

        btnHint = v.findViewById(R.id.btnHint);
        btnCheck = v.findViewById(R.id.btnCheck);
        btnCheck.setOnClickListener(view -> onCheckClicked());

        GameState gs = GameState.get();
        if (btnHint != null) {
            btnHint.setVisibility(gs.hintCredits > 0 ? View.VISIBLE : View.GONE);
            btnHint.setOnClickListener(vw -> onHintClicked());
        }

        etFeedback = v.findViewById(R.id.etFeedback);
        btnSubmitFeedback = v.findViewById(R.id.btnSubmitFeedback);
        btnSubmitFeedback.setOnClickListener(view -> {
            String txt = etFeedback.getText() == null ? "" : etFeedback.getText().toString().trim();
            if (txt.isEmpty()) {
                Toast.makeText(getContext(), "Type feedback first.", Toast.LENGTH_SHORT).show();
                return;
            }

            Toast.makeText(getContext(), "Thanks; feedback saved.", Toast.LENGTH_SHORT).show();
            etFeedback.setText("");
        });


        final TextView[] selected = new TextView[] { null };
        View.OnClickListener pickItem = vv -> {
            TextView t = (TextView) vv;
            selected[0] = t;
            t.animate().scaleX(1.08f).scaleY(1.08f).setDuration(120).withEndAction(() ->
                    t.animate().scaleX(1.0f).scaleY(1.0f).setDuration(120).start()
            ).start();
        };
        tvDrag1.setOnClickListener(pickItem);
        tvDrag2.setOnClickListener(pickItem);
        tvDrag3.setOnClickListener(pickItem);

        View.OnClickListener placeSlot = vv -> {
            if (selected[0] == null) return;
            TextView slot = (TextView) vv;
            slot.setText(selected[0].getText());
            slot.setBackgroundResource(R.drawable.bg_slot_filled);
            selected[0] = null;
        };
        slot1.setOnClickListener(placeSlot);
        slot2.setOnClickListener(placeSlot);
        slot3.setOnClickListener(placeSlot);


        setUpDraggable(tvDrag1);
        setUpDraggable(tvDrag2);
        setUpDraggable(tvDrag3);
        setUpDrop(slot1);
        setUpDrop(slot2);
        setUpDrop(slot3);


        if (gs.lives <= 0) {
            tvExplanation.setText("You are out of hearts. Wait for hearts to recharge or buy more in the shop.");
            tvQuestion.setText("");
            rgOptions.setVisibility(View.GONE);
            dragArea.setVisibility(View.GONE);
            btnCheck.setEnabled(false);
            return v;
        }

        if (q == null) {
            tvExplanation.setText("");
            tvQuestion.setText("No question available.");
            btnCheck.setEnabled(false);
            return v;
        }

        bindQuestion();
        return v;
    }

    private void bindQuestion() {
        answered = false;
        answeredCorrect = false;

        tvExplanation.setText(q.getLesson());
        tvQuestion.setText(q.getPrompt());

        if (q.getType() == Question.Type.MULTIPLE_CHOICE) {
            rgOptions.setVisibility(View.VISIBLE);
            dragArea.setVisibility(View.GONE);


            rbOption1.setText(q.getOptions()[0]);
            rbOption2.setText(q.getOptions()[1]);
            rbOption3.setText(q.getOptions()[2]);
            rgOptions.clearCheck();

        } else {
            rgOptions.setVisibility(View.GONE);
            dragArea.setVisibility(View.VISIBLE);

            List<String> items = q.getDragItems();
            tvDrag1.setText(items.get(0));
            tvDrag2.setText(items.get(1));
            tvDrag3.setText(items.get(2));

            clearSlot(slot1);
            clearSlot(slot2);
            clearSlot(slot3);
        }
    }

    private void clearSlot(TextView slot) {
        slot.setText("Drop here");
        slot.setBackgroundResource(R.drawable.bg_slot_empty);
    }

    private void setUpDraggable(TextView tv) {
        tv.setOnLongClickListener(v -> {
            ClipData data = ClipData.newPlainText("label", tv.getText());
            View.DragShadowBuilder shadow = new View.DragShadowBuilder(tv);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                v.startDragAndDrop(data, shadow, tv, 0);
            } else {
                v.startDrag(data, shadow, tv, 0);
            }
            return true;
        });
    }

    private void setUpDrop(TextView slot) {
        slot.setOnDragListener((v, event) -> {
            if (event.getAction() == DragEvent.ACTION_DROP) {
                String label = event.getClipData().getItemAt(0).getText().toString();
                slot.setText(label);
                slot.setBackgroundResource(R.drawable.bg_slot_filled);
                return true;
            }
            return true;
        });
    }

    private void onCheckClicked() {
        // Allow multiple attempts until correct
        if (answeredCorrect) return;

        boolean correct;

        if (q.getType() == Question.Type.MULTIPLE_CHOICE) {
            int checkedId = rgOptions.getCheckedRadioButtonId();
            if (checkedId == -1) {
                Toast.makeText(getContext(), "Choose an answer first.", Toast.LENGTH_SHORT).show();
                return;
            }
            int selectedIndex =
                    (checkedId == R.id.rbOption1) ? 0 :
                    (checkedId == R.id.rbOption2) ? 1 : 2;

            correct = (selectedIndex == q.getCorrectIndex());
        } else {

            String a = slot1.getText().toString();
            String b = slot2.getText().toString();
            String c = slot3.getText().toString();


            if (a.trim().isEmpty() || b.trim().isEmpty() || c.trim().isEmpty()) {
                Toast.makeText(getContext(), "Fill all slots first.", Toast.LENGTH_SHORT).show();
                return;
            }

            List<String> correctOrder = q.getCorrectOrder();
            correct = a.equals(correctOrder.get(0))
                    && b.equals(correctOrder.get(1))
                    && c.equals(correctOrder.get(2));
        }

        answered = true;
        answeredCorrect = correct;

        if (correct) {
            GameState gs = GameState.get();
            int reward = TOKENS_PER_CORRECT * (gs.scoreMultiplier ? 2 : 1);

            // Award gems once
            gs.addTokens(reward);

            Toast.makeText(getContext(), "✅ Correct! (+" + reward + " gems)", Toast.LENGTH_SHORT).show();

            // Update header
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).updateHeader();
            }


            Fragment p = getParentFragment();
            if (p instanceof Listener) {
                ((Listener) p).onAnswered(index, true);
                ((Listener) p).onRequestAdvance(index);
            }
        } else {

            answered = false;
            answeredCorrect = false;

            // cost a heart on wrong attempt
            GameState.get().loseLife();
            Toast.makeText(getContext(), "❌ Not quite. Try again. (-1 heart)", Toast.LENGTH_SHORT).show();

            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).updateHeader();
            }

            Fragment p = getParentFragment();
            if (p instanceof Listener) {
                ((Listener) p).onAnswered(index, false);
            }
        }
    }


private void onHintClicked() {
    GameState gs = GameState.get();
    if (!gs.consumeHintCredit()) {
        if (btnHint != null) btnHint.setVisibility(View.GONE);
        Toast.makeText(getContext(), "No hints available.", Toast.LENGTH_SHORT).show();
        return;
    }

    if (q == null) return;

    if (q.getType() == com.example.smartly.model.Question.Type.MULTIPLE_CHOICE) {
        int idx = q.getCorrectIndex();
        String[] opts = q.getOptions();
        String answer = (opts != null && idx >= 0 && idx < opts.length) ? opts[idx] : "the correct option";

        if (idx == 0) rbOption1.setChecked(true);
        else if (idx == 1) rbOption2.setChecked(true);
        else if (idx == 2) rbOption3.setChecked(true);

        Toast.makeText(getContext(), "Hint: " + answer, Toast.LENGTH_LONG).show();
    } else {
        java.util.List<String> order = q.getCorrectOrder();
        if (order != null && !order.isEmpty()) {
            Toast.makeText(getContext(), "Hint: " + android.text.TextUtils.join(" → ", order), Toast.LENGTH_LONG).show();
            if (slot1 != null) slot1.setText(order.size() > 0 ? order.get(0) : "");
            if (slot2 != null) slot2.setText(order.size() > 1 ? order.get(1) : "");
            if (slot3 != null) slot3.setText(order.size() > 2 ? order.get(2) : "");
        } else {
            Toast.makeText(getContext(), "Hint: (no answer data)", Toast.LENGTH_SHORT).show();
        }
    }

    if (getContext() != null) gs.saveToPrefs(getContext());
    if (btnHint != null) btnHint.setVisibility(gs.hintCredits > 0 ? View.VISIBLE : View.GONE);
}

}