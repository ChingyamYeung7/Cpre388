package com.example.smartly;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.smartly.model.UserProfile;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.HashSet;
import java.util.Set;

public class GameState {


    private static GameState instance;

    public static GameState get() {
        if (instance == null) {
            instance = new GameState();
        }
        return instance;
    }

    private GameState() {
        tokens = 0;
        lives = MAX_LIVES;
        highScore = 0;
        totalCorrect = 0;
        scoreMultiplier = false;
		scoreMultiplierModulesLeft = 0;
        avatarGlow = false;
            hintCredits = 0;
        currentCourseId = null;
        profile = null;
        completedCourses = new HashSet<>();
        lastLifeTimeMillis = System.currentTimeMillis();
    }


    public static final int MAX_LIVES = 5;

    private static final long LIFE_INTERVAL_MILLIS = 5L * 60L * 1000L;


    private static final String PREFS_NAME = "smartly_state";
    private static final String KEY_TOKENS = "tokens";
    private static final String KEY_LIVES = "lives";
    private static final String KEY_TOTAL_CORRECT = "total_correct";
    private static final String KEY_LAST_LIFE_TIME = "last_life_time";
    private static final String KEY_COMPLETED_COURSES = "completed_courses";
    private static final String KEY_USER_ID = "user_id";


    private static final String KEY_SCORE_MULTIPLIER = "score_multiplier";

    private static final String KEY_SCORE_MULTIPLIER_LEFT = "score_multiplier_left";
    private static final String KEY_AVATAR_GLOW = "avatar_glow";


    private static final String KEY_HINT_CREDITS = "hint_credits";


    public String currentCourseId;


    public Set<String> completedCourses;


    public int tokens;


    public int lives;


    public long lastLifeTimeMillis;


    public int highScore;


    public int totalCorrect;


    public int hintCredits;


    public boolean scoreMultiplier;

	public int scoreMultiplierModulesLeft;
    public boolean avatarGlow;


    public UserProfile profile;


    /** Load hearts, tokens, completed courses *for this Firebase user*. Call once in MainActivity.onCreate(). */
    public void loadFromPrefs(Context context) {
        SharedPreferences sp = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        FirebaseUser current = FirebaseAuth.getInstance().getCurrentUser();
        String currentUserId = (current != null) ? current.getUid() : null;
        String savedUserId = sp.getString(KEY_USER_ID, null);

        if (savedUserId != null && currentUserId != null && !savedUserId.equals(currentUserId)) {
            tokens = 0;
            lives = MAX_LIVES;
            totalCorrect = 0;
            completedCourses = new HashSet<>();
            lastLifeTimeMillis = System.currentTimeMillis();

            scoreMultiplier = false;
            scoreMultiplierModulesLeft = 0;
            avatarGlow = false;
            hintCredits = 0;

            sp.edit()
                    .putString(KEY_USER_ID, currentUserId)
                    .putInt(KEY_TOKENS, tokens)
                    .putInt(KEY_LIVES, lives)
                    .putInt(KEY_TOTAL_CORRECT, totalCorrect)
                    .putLong(KEY_LAST_LIFE_TIME, lastLifeTimeMillis)
                    .putStringSet(KEY_COMPLETED_COURSES, completedCourses)
                    .putBoolean(KEY_SCORE_MULTIPLIER, scoreMultiplier)
                    .putInt(KEY_SCORE_MULTIPLIER_LEFT, scoreMultiplierModulesLeft)
                    .putBoolean(KEY_AVATAR_GLOW, avatarGlow)
                    .apply();
            return;
        }

        if (currentUserId != null && savedUserId == null) {
            sp.edit().putString(KEY_USER_ID, currentUserId).apply();
        }


        if (currentUserId != null && savedUserId == null) {
            tokens = 0;
            lives = MAX_LIVES;
            totalCorrect = 0;
            completedCourses = new HashSet<>();
            lastLifeTimeMillis = System.currentTimeMillis();
            scoreMultiplier = false;
            scoreMultiplierModulesLeft = 0;
            avatarGlow = false;
            hintCredits = 0;

            sp.edit()
                    .putString(KEY_USER_ID, currentUserId)
                    .putInt(KEY_TOKENS, tokens)
                    .putInt(KEY_LIVES, lives)
                    .putInt(KEY_TOTAL_CORRECT, totalCorrect)
                    .putLong(KEY_LAST_LIFE_TIME, lastLifeTimeMillis)
                    .putStringSet(KEY_COMPLETED_COURSES, completedCourses)
                    .putBoolean(KEY_SCORE_MULTIPLIER, scoreMultiplier)
                    .putInt(KEY_SCORE_MULTIPLIER_LEFT, scoreMultiplierModulesLeft)
                    .putBoolean(KEY_AVATAR_GLOW, avatarGlow)
                    .apply();
            return;
        }

        tokens = sp.getInt(KEY_TOKENS, tokens);
        lives = sp.getInt(KEY_LIVES, lives);
        totalCorrect = sp.getInt(KEY_TOTAL_CORRECT, totalCorrect);
        lastLifeTimeMillis = sp.getLong(KEY_LAST_LIFE_TIME, lastLifeTimeMillis);

        // Shop
        scoreMultiplier = sp.getBoolean(KEY_SCORE_MULTIPLIER, scoreMultiplier);
        scoreMultiplierModulesLeft = sp.getInt(KEY_SCORE_MULTIPLIER_LEFT, scoreMultiplierModulesLeft);
        avatarGlow = sp.getBoolean(KEY_AVATAR_GLOW, avatarGlow);
        hintCredits = sp.getInt(KEY_HINT_CREDITS, hintCredits);


        if (scoreMultiplierModulesLeft < 0) scoreMultiplierModulesLeft = 0;
        if (scoreMultiplier && scoreMultiplierModulesLeft == 0) scoreMultiplier = false;

        Set<String> savedSet = sp.getStringSet(KEY_COMPLETED_COURSES, null);
        if (savedSet != null) {
            completedCourses = new HashSet<>(savedSet);
        } else if (completedCourses == null) {
            completedCourses = new HashSet<>();
        }


        if (lives < 0) lives = 0;
        if (lives > MAX_LIVES) lives = MAX_LIVES;
    }

    /** Save hearts, tokens, timer and completed courses into SharedPreferences for this user. */
    public void saveToPrefs(Context context) {
        SharedPreferences sp = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        FirebaseUser current = FirebaseAuth.getInstance().getCurrentUser();
        String currentUserId = (current != null) ? current.getUid() : null;

        SharedPreferences.Editor ed = sp.edit();
        if (currentUserId != null) {
            ed.putString(KEY_USER_ID, currentUserId);
        }

        ed.putInt(KEY_TOKENS, tokens);
        ed.putInt(KEY_LIVES, lives);
        ed.putInt(KEY_TOTAL_CORRECT, totalCorrect);
        ed.putLong(KEY_LAST_LIFE_TIME, lastLifeTimeMillis);
        ed.putBoolean(KEY_SCORE_MULTIPLIER, scoreMultiplier);
        ed.putInt(KEY_SCORE_MULTIPLIER_LEFT, scoreMultiplierModulesLeft);
        ed.putBoolean(KEY_AVATAR_GLOW, avatarGlow);
        ed.putInt(KEY_HINT_CREDITS, hintCredits);
        ed.putStringSet(KEY_COMPLETED_COURSES,
                (completedCourses != null) ? new HashSet<>(completedCourses) : new HashSet<>());
        ed.apply();
    }



    public void addTokens(int amount) {
        if (amount <= 0) return;
        tokens += amount;
    }

    public void addCorrect(int count) {
        if (count <= 0) return;
        totalCorrect += count;
    }

    public boolean trySpendTokens(int cost) {
        if (tokens >= cost) {
            tokens -= cost;
            return true;
        }
        return false;
    }

    /** Add one hint credit (each credit can reveal the answer to one question). */
    public void addHintCredit() {
        hintCredits = Math.max(0, hintCredits + 1);
    }

    /** Consume one hint credit; returns true if a hint was available and consumed. */
    public boolean consumeHintCredit() {
        if (hintCredits > 0) {
            hintCredits -= 1;
            return true;
        }
        return false;
    }

    public boolean loseLife() {
        if (lives <= 0) {
            return false;
        }
        lives--;
        lastLifeTimeMillis = System.currentTimeMillis();
        return true;
    }

    /** Regenerate lives over time. Call in MainActivity.updateHeader(). */
    public void updateLivesFromTimer() {
        long now = System.currentTimeMillis();
        if (lives >= MAX_LIVES) {
            lastLifeTimeMillis = now;
            return;
        }

        long elapsed = now - lastLifeTimeMillis;
        if (elapsed < LIFE_INTERVAL_MILLIS) return;

        long livesToAddLong = elapsed / LIFE_INTERVAL_MILLIS;
        if (livesToAddLong <= 0) return;

        int livesToAdd = (int) livesToAddLong;
        int newLives = lives + livesToAdd;

        if (newLives >= MAX_LIVES) {
            lives = MAX_LIVES;
            lastLifeTimeMillis = now;
        } else {
            lives = newLives;
            long usedTime = livesToAddLong * LIFE_INTERVAL_MILLIS;
            long remaining = elapsed - usedTime;
            lastLifeTimeMillis = now - remaining;
        }
    }

    public long millisUntilNextLife() {
        if (lives >= MAX_LIVES) return 0;
        long now = System.currentTimeMillis();
        long elapsed = now - lastLifeTimeMillis;
        long remaining = LIFE_INTERVAL_MILLIS - elapsed;
        return Math.max(remaining, 0);
    }



    public boolean isCourseCompleted(String courseId) {
        return completedCourses != null && completedCourses.contains(courseId);
    }

    public void markCourseCompleted(String courseId) {
        if (completedCourses == null) {
            completedCourses = new HashSet<>();
        }
        if (courseId != null) {
            completedCourses.add(courseId);
        }
    }



    /** Activate the x2 multiplier for a fixed number of module completions. */
    public void activateScoreMultiplier(int modules) {
        scoreMultiplier = true;
        scoreMultiplierModulesLeft = Math.max(0, modules);
        if (scoreMultiplierModulesLeft == 0) scoreMultiplier = false;
    }

    /** Call once when a user finishes a module; decrements the multiplier counter if active. */
    public void onModuleFinished() {
        if (!scoreMultiplier) return;
        if (scoreMultiplierModulesLeft > 0) scoreMultiplierModulesLeft--;
        if (scoreMultiplierModulesLeft <= 0) {
            scoreMultiplierModulesLeft = 0;
            scoreMultiplier = false;
        }
    }
}
