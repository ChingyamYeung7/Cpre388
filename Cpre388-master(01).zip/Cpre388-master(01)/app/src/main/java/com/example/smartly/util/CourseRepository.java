package com.example.smartly.util;

import com.example.smartly.model.Course;

import java.util.ArrayList;
import java.util.List;

public class CourseRepository {

    private static final List<Course> COURSES = new ArrayList<>();

    static {
        // Week 1: Voltage
        COURSES.add(new Course(
                "week1_voltage",
                "Week 1 – Voltage",
                "Voltage as height & energy"
        ));

        // Week 2: Current
        COURSES.add(new Course(
                "week2_current",
                "Week 2 – Current",
                "Current as electric flow"
        ));

        // ✅ Week 3: Resistors (NEW)
        COURSES.add(new Course(
                "week3_resistors",
                "Week 3 – Discuss Resistors",
                "What a resistor does and how it limits current"
        ));

        // Week 4: Series Circuits
        COURSES.add(new Course(
                "week4_series",
                "Week 4 – Circuit in Series",
                "One path: current stays the same; voltages add up"
        ));

        // Week 5: Parallel Circuits
        COURSES.add(new Course(
                "week5_parallel",
                "Week 5 – Parallel Circuits",
                "Multiple paths: voltage same; currents split"
        ));

        // Week 6: Power & Energy
        COURSES.add(new Course(
                "week6_power",
                "Week 6 – Power & Energy",
                "P = VI basics"
        ));

        // Week 7: Capacitors
        COURSES.add(new Course(
                "week7_capacitors",
                "Week 7 – Capacitors",
                "Charge storage and C = Q/V"
        ));

        // Week 8: RC Transients
        COURSES.add(new Course(
                "week8_rc",
                "Week 8 – RC Transients",
                "Time constant and step response"
        ));

        // Extra modules so Home paging (5 per page) is exercised
        COURSES.add(new Course(
                "week9_dividers",
                "Week 9 – Voltage Dividers",
                "Divider rule and loading"
        ));
        COURSES.add(new Course(
                "week10_thevenin",
                "Week 10 – Thévenin",
                "Equivalent circuits"
        ));
    }

    public static List<Course> getAllCourses() {
        return COURSES;
    }

    public static Course getCourseById(String id) {
        for (Course c : COURSES) {
            if (c.id.equals(id)) return c;
        }
        return null;
    }
}
