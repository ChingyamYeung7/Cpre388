package com.example.smartly.util;

import com.example.smartly.model.Question;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class QuestionRepository {

    public static List<Question> getQuestionsForCourse(String courseId) {
        switch (courseId) {
            case "week1_voltage":
                return getWeek1VoltageQuestions();
            case "week2_current":
                return getWeek2CurrentQuestions();
            case "week3_resistors":
                return getWeek3ResistorsQuestions();
            case "week4_series":
                return getWeek4SeriesQuestions();
            case "week5_parallel":
                return getWeek5ParallelQuestions();
            case "week6_power":
                return getWeek6PowerQuestions();
            case "week7_capacitors":
                return getWeek7CapacitorsQuestions();
            case "week8_rc":
                return getWeek8RCQuestions();
            case "week9_dividers":
                return getWeek9DividersQuestions();
            case "week10_thevenin":
                return getWeek10TheveninQuestions();
            default:
                return new ArrayList<>();
        }
    }

    // ---------- WEEK 1: VOLTAGE ----------
    private static List<Question> getWeek1VoltageQuestions() {
        List<Question> list = new ArrayList<>();

        list.add(Question.mcq(
                "week1_voltage",
                "Lesson: Voltage is like electrical “height” (energy level). Higher voltage means higher electrical potential.",
                "Q1: Voltage is most similar to:",
                new String[]{"Height / energy level", "Wire thickness", "Current flow speed"},
                0,
                "Correct — voltage represents electrical potential (like height).",
                "Not quite — thickness and speed are not voltage."
        ));

        list.add(Question.mcq(
                "week1_voltage",
                "Lesson: Electricity “wants to move” when there is a voltage difference (high to low).",
                "Q2: What is required for current to start flowing?",
                new String[]{"A voltage difference", "Only a resistor", "Only ground (0V) with nothing else"},
                0,
                "Yes — voltage difference provides the push.",
                "No — you need a difference (high vs low)."
        ));

        list.add(Question.mcq(
                "week1_voltage",
                "Lesson: Ground is a reference point, defined as 0 V.",
                "Q3 (Technique): If point A is 9 V and ground is 0 V, the voltage difference is:",
                new String[]{"9 V", "0 V", "-9 V"},
                0,
                "Correct — 9V above ground means a 9V difference.",
                "Careful — ground is 0V, so the difference is 9V."
        ));

        return list;
    }

    // ---------- WEEK 2: CURRENT ----------
    private static List<Question> getWeek2CurrentQuestions() {
        List<Question> list = new ArrayList<>();

        list.add(Question.mcq(
                "week2_current",
                "Lesson: Current is the flow rate of electric charge (like water flow rate in a pipe).",
                "Q1: Electric current is:",
                new String[]{"Flow of electric charge", "Electrical height", "Opposition to flow"},
                0,
                "Correct — current is charge flow per time.",
                "No — height is voltage; opposition is resistance."
        ));

        list.add(Question.mcq(
                "week2_current",
                "Lesson: Voltage is the push. With no voltage difference, there is no push.",
                "Q2: If the voltage difference is 0V, current is:",
                new String[]{"0 (no flow)", "Maximum", "Random"},
                0,
                "Correct — no push means no flow (simplified model).",
                "No — current needs a voltage difference."
        ));

        list.add(Question.mcq(
                "week2_current",
                "Lesson: Conventional current direction is defined from high voltage to low voltage.",
                "Q3 (Technique): Conventional current direction is:",
                new String[]{"High voltage → low voltage", "Low voltage → high voltage", "No defined direction"},
                0,
                "Correct — that’s the definition used in circuit diagrams.",
                "Not correct — diagrams use high → low for conventional current."
        ));

        return list;
    }

    // ---------- WEEK 3: RESISTORS ----------
    private static List<Question> getWeek3ResistorsQuestions() {
        List<Question> list = new ArrayList<>();

        list.add(Question.mcq(
                "week3_resistors",
                "Lesson: A resistor limits current. More resistance means less current if voltage stays the same (I = V/R).",
                "Q1: Main job of a resistor:",
                new String[]{"Limit current", "Increase voltage", "Create energy"},
                0,
                "Correct — resistors limit current.",
                "No — resistors don’t increase voltage or create energy."
        ));

        list.add(Question.mcq(
                "week3_resistors",
                "Lesson: If V is constant, increasing R decreases I (Ohm’s Law).",
                "Q2: If you double R (same V), current becomes:",
                new String[]{"Half", "Double", "Same"},
                0,
                "Correct — I = V/R.",
                "No — current is inversely proportional to resistance."
        ));

        list.add(Question.dragDropOrder(
                "week3_resistors",
                "Lesson: In a simple loop, current goes source → resistor → back.",
                "Q3 (Drag): Arrange a simple loop order:",
                Arrays.asList("Battery", "Resistor", "Return"),
                Arrays.asList("Battery", "Resistor", "Return"),
                "Correct — that forms a simple loop.",
                "Try: source first, then element, then return path."
        ));

        return list;
    }

    // ---------- WEEK 4: SERIES ----------
    private static List<Question> getWeek4SeriesQuestions() {
        List<Question> list = new ArrayList<>();

        list.add(Question.mcq(
                "week4_series",
                "Lesson: A series circuit has ONE path for current. Components are end-to-end.",
                "Q1: A series circuit means:",
                new String[]{"One path for current", "Many paths for current", "No current can ever flow"},
                0,
                "Correct — series has one path.",
                "No — many paths describes parallel."
        ));

        list.add(Question.dragDropOrder(
                "week4_series",
                "Lesson: In series, current flows through each component in order along one loop.",
                "Q2 (Drag): Arrange a valid series path order:",
                Arrays.asList("Battery", "Resistor", "LED"),
                Arrays.asList("Battery", "Resistor", "LED"),
                "Correct — that forms a simple series loop order.",
                "In series, it’s one path: source → component → component."
        ));

        list.add(Question.mcq(
                "week4_series",
                "Lesson: In a series circuit, current does not split.",
                "Q3: Which statement is TRUE in series?",
                new String[]{"Current is the same everywhere", "Voltage is the same everywhere", "Resistance becomes zero"},
                0,
                "Correct — current is the same through all series components.",
                "No — voltage divides in series; current stays the same."
        ));

        return list;
    }

    // ---------- WEEK 5: PARALLEL ----------
    private static List<Question> getWeek5ParallelQuestions() {
        List<Question> list = new ArrayList<>();

        list.add(Question.mcq(
                "week5_parallel",
                "Lesson: In a parallel circuit, all branches share the same voltage across them.",
                "Q1: In parallel, the voltage across each branch is:",
                new String[]{"The same", "Split equally", "Always zero"},
                0,
                "Correct — each branch sees the same voltage.",
                "Not quite — current splits; voltage stays the same."
        ));

        list.add(Question.mcq(
                "week5_parallel",
                "Lesson: Total current is the sum of branch currents (KCL).",
                "Q2: I_total equals:",
                new String[]{"I1 + I2 + ...", "V1 + V2 + ...", "R1 + R2 + ..."},
                0,
                "Correct — currents add at a node.",
                "No — voltages/resistances don’t add like that in parallel."
        ));

        list.add(Question.dragDropOrder(
                "week5_parallel",
                "Lesson: A parallel connection shares the same two nodes.",
                "Q3 (Drag): Put these in a parallel-branch idea order:",
                Arrays.asList("Node A", "Branch 1", "Branch 2", "Node B"),
                Arrays.asList("Node A", "Branch 1", "Branch 2", "Node B"),
                "Correct — branches connect between the same two nodes.",
                "Parallel means the branches connect across the same two nodes."
        ));

        return list;
    }

    // ---------- WEEK 6: POWER ----------
    private static List<Question> getWeek6PowerQuestions() {
        List<Question> list = new ArrayList<>();

        list.add(Question.mcq(
                "week6_power",
                "Lesson: Power is the rate of energy transfer. In circuits: P = V·I.",
                "Q1: Power in a circuit is:",
                new String[]{"V × I", "V ÷ I", "I ÷ V"},
                0,
                "Correct — P = V·I.",
                "No — P is proportional to both V and I."
        ));

        list.add(Question.mcq(
                "week6_power",
                "Lesson: If you increase voltage while holding current constant, power increases.",
                "Q2: If V doubles and I stays the same, P becomes:",
                new String[]{"2×", "1/2×", "4×"},
                0,
                "Correct — P = V·I so doubling V doubles P.",
                "No — it’s linear in V if I is constant."
        ));

        list.add(Question.dragDropOrder(
                "week6_power",
                "Lesson: Units check: volts × amps = watts.",
                "Q3 (Drag): Order the unit conversion idea:",
                Arrays.asList("Volts", "Amps", "Watts"),
                Arrays.asList("Volts", "Amps", "Watts"),
                "Correct — V × A = W.",
                "Hint: power uses watts."
        ));

        return list;
    }

    // ---------- WEEK 7: CAPACITORS ----------
    private static List<Question> getWeek7CapacitorsQuestions() {
        List<Question> list = new ArrayList<>();

        list.add(Question.mcq(
                "week7_capacitors",
                "Lesson: A capacitor stores charge. Basic relation: Q = C·V.",
                "Q1: Capacitors primarily store:",
                new String[]{"Charge", "Resistance", "Current"},
                0,
                "Correct — capacitors store charge.",
                "No — resistors dissipate; current is a flow, not storage."
        ));

        list.add(Question.mcq(
                "week7_capacitors",
                "Lesson: For a fixed C, bigger V means bigger stored Q.",
                "Q2: If V doubles (same C), charge Q becomes:",
                new String[]{"2×", "1/2×", "4×"},
                0,
                "Correct — Q = C·V.",
                "No — it scales linearly with V."
        ));

        list.add(Question.dragDropOrder(
                "week7_capacitors",
                "Lesson: A simple capacitor model: charge builds up over time when connected to a source.",
                "Q3 (Drag): Simple story order:",
                Arrays.asList("Connect", "Charge accumulates", "Voltage rises"),
                Arrays.asList("Connect", "Charge accumulates", "Voltage rises"),
                "Correct — connection leads to charge accumulation which raises voltage.",
                "Try: what happens first when you connect it?"
        ));

        return list;
    }

    // ---------- WEEK 8: RC ----------
    private static List<Question> getWeek8RCQuestions() {
        List<Question> list = new ArrayList<>();

        list.add(Question.mcq(
                "week8_rc",
                "Lesson: RC time constant τ = R·C controls how fast the capacitor charges/discharges.",
                "Q1: The RC time constant is:",
                new String[]{"R × C", "R ÷ C", "C ÷ R"},
                0,
                "Correct — τ = R·C.",
                "No — it’s the product of R and C."
        ));

        list.add(Question.mcq(
                "week8_rc",
                "Lesson: Bigger τ means slower response.",
                "Q2: If R increases, the charging is:",
                new String[]{"Slower", "Faster", "Unchanged"},
                0,
                "Correct — larger R increases τ.",
                "No — larger τ means slower change."
        ));

        list.add(Question.dragDropOrder(
                "week8_rc",
                "Lesson: Step response is often described as 0τ → 1τ → 2τ ...",
                "Q3 (Drag): Order early time points:",
                Arrays.asList("0τ", "1τ", "2τ"),
                Arrays.asList("0τ", "1τ", "2τ"),
                "Correct — that’s the standard time labeling.",
                "Hint: start at 0τ."
        ));

        return list;
    }

    // ---------- WEEK 9: DIVIDERS ----------
    private static List<Question> getWeek9DividersQuestions() {
        List<Question> list = new ArrayList<>();

        list.add(Question.mcq(
                "week9_dividers",
                "Lesson: Voltage divider with R1 on top, R2 on bottom: Vout = Vin·R2/(R1+R2).",
                "Q1: In the standard divider, Vout is taken across:",
                new String[]{"The bottom resistor (R2)", "The top resistor (R1)", "Both in series equally"},
                0,
                "Correct — standard Vout is across R2.",
                "No — the standard formula uses R2 in the numerator."
        ));

        list.add(Question.mcq(
                "week9_dividers",
                "Lesson: If R2 increases (R1 fixed), the fraction R2/(R1+R2) increases.",
                "Q2: If R2 increases, Vout typically:",
                new String[]{"Increases", "Decreases", "Stays the same"},
                0,
                "Correct — the divider ratio increases.",
                "No — bigger R2 increases the output fraction."
        ));

        list.add(Question.dragDropOrder(
                "week9_dividers",
                "Lesson: Divider stack is Vin → R1 → node (Vout) → R2 → ground.",
                "Q3 (Drag): Put the divider stack in order:",
                Arrays.asList("Vin", "R1", "Vout node", "R2", "GND"),
                Arrays.asList("Vin", "R1", "Vout node", "R2", "GND"),
                "Correct — that’s the classic divider.",
                "Hint: Vout is the middle node between R1 and R2."
        ));

        return list;
    }

    // ---------- WEEK 10: THEVENIN ----------
    private static List<Question> getWeek10TheveninQuestions() {
        List<Question> list = new ArrayList<>();

        list.add(Question.mcq(
                "week10_thevenin",
                "Lesson: Thévenin equivalent replaces a network with Vth in series with Rth.",
                "Q1: Thévenin equivalent looks like:",
                new String[]{"V source in series with R", "I source in series with R", "Two resistors in parallel"},
                0,
                "Correct — Vth series Rth.",
                "No — Norton is I source in parallel with R."
        ));

        list.add(Question.mcq(
                "week10_thevenin",
                "Lesson: To find Rth, turn off independent sources (V→short, I→open).",
                "Q2: Turning off an ideal voltage source means:",
                new String[]{"Replace with a short", "Replace with an open", "Remove all resistors"},
                0,
                "Correct — short an ideal V source.",
                "No — current sources open; voltage sources short."
        ));

        list.add(Question.dragDropOrder(
                "week10_thevenin",
                "Lesson: Typical steps: remove load; find Vth; find Rth; then reconnect load.",
                "Q3 (Drag): Order the steps:",
                Arrays.asList("Find Rth", "Reconnect load", "Remove load", "Find Vth"),
                Arrays.asList("Remove load", "Find Vth", "Find Rth", "Reconnect load"),
                "Correct — remove load → Vth → Rth → reconnect.",
                "Try again — compute Vth with the load removed first."
        ));

        return list;
    }
}
