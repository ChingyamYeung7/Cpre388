package com.example.smartly.UI;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.example.smartly.GameState;
import com.example.smartly.R;
import com.example.smartly.model.Question;
import com.example.smartly.util.QuestionRepository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Swipeable, multi-page "work problems" experience.
 * - ViewPager2 for paging
 * - Progress bars for navigation + completion
 */
public class ProblemSetFragment extends Fragment implements QuestionPageFragment.Listener {

    private static final String ARG_COURSE_ID = "courseId";

    private String courseId;

    private ViewPager2 pager;
    private ProgressBar pbProgress;
    private TextView tvCounter;
    private Button btnPrev, btnNext;

    private List<Question> questions = new ArrayList<>();
    private final Set<Integer> answeredCorrect = new HashSet<>();

    public static ProblemSetFragment newInstance(String courseId) {
        ProblemSetFragment f = new ProblemSetFragment();
        Bundle b = new Bundle();
        b.putString(ARG_COURSE_ID, courseId);
        f.setArguments(b);
        return f;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            courseId = getArguments().getString(ARG_COURSE_ID);
        }
        questions = QuestionRepository.getQuestionsForCourse(courseId);
        if (questions == null) questions = new ArrayList<>();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_problem_set, container, false);

        pager = v.findViewById(R.id.pager);
        pbProgress = v.findViewById(R.id.pbProgress);
        tvCounter = v.findViewById(R.id.tvCounter);
        btnPrev = v.findViewById(R.id.btnPrev);
        btnNext = v.findViewById(R.id.btnNext);

        pbProgress.setMax(Math.max(1, questions.size()));

        pager.setAdapter(new ProblemSetPagerAdapter(this, courseId, questions.size()));
        pager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                updateNavUI(position);
            }
        });

        btnPrev.setOnClickListener(view -> {
            int p = pager.getCurrentItem();
            if (p > 0) pager.setCurrentItem(p - 1, true);
        });

        btnNext.setOnClickListener(view -> {
            int p = pager.getCurrentItem();
            if (p < questions.size() - 1) {
                pager.setCurrentItem(p + 1, true);
            } else {
                finishSet();
            }
        });

        updateNavUI(0);

        return v;
    }


    private void finishSet() {
        int score = answeredCorrect.size();
        int total = Math.max(0, questions.size());

        GameState gs = GameState.get();


        gs.onModuleFinished();

        boolean passed = score >= Math.max(1, total / 2);

        boolean firstTimeForLeaderboard = !gs.isCourseCompleted(courseId);
        if (passed) {
            gs.markCourseCompleted(courseId);
            if (firstTimeForLeaderboard) {
                gs.addCorrect(score);
            }
        }


        try {
            com.google.firebase.auth.FirebaseUser user =
                    com.google.firebase.auth.FirebaseAuth.getInstance().getCurrentUser();
            String uid = (user != null) ? user.getUid() : null;
            if (uid != null) {
                String name = null;
                if (gs.profile != null && gs.profile.username != null && !gs.profile.username.trim().isEmpty()) {
                    name = gs.profile.username.trim();
                }
                if (name == null) name = (user.getEmail() != null) ? user.getEmail() : "Player";

                com.google.firebase.firestore.FirebaseFirestore db = com.google.firebase.firestore.FirebaseFirestore.getInstance();
                com.example.smartly.model.ScoreEntry entry = new com.example.smartly.model.ScoreEntry(uid, name, gs.totalCorrect);
                db.collection("scores").document(uid)
                        .set(entry, com.google.firebase.firestore.SetOptions.merge())
                        .addOnFailureListener(e -> { /* swallow */ });
            }
        } catch (Exception ignored) {}

        if (getActivity() instanceof com.example.smartly.MainActivity) {
            CongratsFragment cf = CongratsFragment.newInstance(courseId, score, total);
            ((com.example.smartly.MainActivity) getActivity()).loadFragment(cf);
        }
    }

    private void updateNavUI(int position) {
        tvCounter.setText((position + 1) + " / " + Math.max(1, questions.size()));
        pbProgress.setProgress(position + 1);

        btnPrev.setEnabled(position > 0);
        btnNext.setText(position == questions.size() - 1 ? "Finish" : "Next");
    }

    @Override
    public void onAnswered(int index, boolean correct) {
        if (correct) {
            answeredCorrect.add(index);
        }
    }

    @Override
    public void onRequestAdvance(int index) {

        if (pager == null) return;

        int p = index;
        if (p < questions.size() - 1) {
            pager.setCurrentItem(p + 1, true);
        } else {
            finishSet();
        }
    }
}
