package com.example.smartly.UI;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class ProblemSetPagerAdapter extends FragmentStateAdapter {

    private final String courseId;
    private final int count;

    public ProblemSetPagerAdapter(@NonNull Fragment fragment, String courseId, int count) {
        super(fragment);
        this.courseId = courseId;
        this.count = Math.max(0, count);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        return QuestionPageFragment.newInstance(courseId, position);
    }

    @Override
    public int getItemCount() {
        return count;
    }
}