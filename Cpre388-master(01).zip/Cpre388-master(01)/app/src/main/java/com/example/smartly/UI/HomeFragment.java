package com.example.smartly.UI;

import android.animation.ObjectAnimator;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.smartly.GameState;
import com.example.smartly.MainActivity;
import com.example.smartly.R;
import com.example.smartly.model.Course;
import com.example.smartly.util.CourseRepository;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private LinearLayout courseContainer;

    // pages
    private ImageView btnPrevModules, btnNextModules;
    private TextView tvModulesPage;
    private int modulesPage = 0;
    private static final int MODULES_PER_PAGE = 4;
    private List<Course> allCourses = new ArrayList<>();



    private View viewGlow;
    private ImageView imgAvatar;
    private TextView tvWelcome, tvTokensMini, tvLivesMini, tvOverallLabel;
    private ProgressBar pbOverall;

    // Quick navigation
    private ImageView btnGoProfile, btnGoPractice, btnGoScores, btnGoShop;

    public HomeFragment() {}

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_home, container, false);

        courseContainer = v.findViewById(R.id.courseContainer);

        btnPrevModules = v.findViewById(R.id.btnPrevModules);
        btnNextModules = v.findViewById(R.id.btnNextModules);
        tvModulesPage  = v.findViewById(R.id.tvModulesPage);

        viewGlow = v.findViewById(R.id.viewGlow);
        imgAvatar = v.findViewById(R.id.imgAvatar);
        tvWelcome = v.findViewById(R.id.tvWelcome);
        tvTokensMini = v.findViewById(R.id.tvTokensMini);
        tvLivesMini = v.findViewById(R.id.tvLivesMini);
        pbOverall = v.findViewById(R.id.pbOverall);
        tvOverallLabel = v.findViewById(R.id.tvOverallLabel);

        btnGoProfile = v.findViewById(R.id.btnGoProfile);
        btnGoPractice = v.findViewById(R.id.btnGoPractice);
        btnGoScores = v.findViewById(R.id.btnGoScores);
        btnGoShop = v.findViewById(R.id.btnGoShop);

        wireQuickNav();

        bindHeader();
        renderCourses(inflater);


        if (btnPrevModules != null) {
            btnPrevModules.setOnClickListener(vw -> {
                modulesPage--;
                renderModulesPage(inflater);
            });
        }
        if (btnNextModules != null) {
            btnNextModules.setOnClickListener(vw -> {
                modulesPage++;
                renderModulesPage(inflater);
            });
        }

        startHeaderAnimations();

        return v;
    }

    private void wireQuickNav() {
        if (!(getActivity() instanceof MainActivity)) return;
        MainActivity a = (MainActivity) getActivity();

        if (btnGoProfile != null) btnGoProfile.setOnClickListener(v -> a.navigateToTab(R.id.nav_profile));
        if (btnGoPractice != null) btnGoPractice.setOnClickListener(v -> a.navigateToTab(R.id.nav_write));
        if (btnGoScores != null) btnGoScores.setOnClickListener(v -> a.navigateToTab(R.id.nav_leaderboard));
        if (btnGoShop != null) btnGoShop.setOnClickListener(v -> a.navigateToTab(R.id.nav_shop));
    }

    @Override
    public void onResume() {
        super.onResume();
        bindHeader();
    }

    private void bindHeader() {
        GameState gs = GameState.get();

        tvWelcome.setText("Welcome back");
        tvTokensMini.setText("💎 " + gs.tokens);
        tvLivesMini.setText("❤️ " + gs.lives + "/" + GameState.MAX_LIVES);


        viewGlow.setVisibility(gs.avatarGlow ? View.VISIBLE : View.GONE);

        // Avatar
        if (imgAvatar != null) {
            String avatarName = (gs.profile != null) ? gs.profile.getAvatarName() : null;
            if (avatarName == null || avatarName.isEmpty()) avatarName = "avatar_default";
            int resId = getResources().getIdentifier(avatarName, "drawable", requireContext().getPackageName());
            if (resId != 0) imgAvatar.setImageResource(resId);
        }

        // Overall progress
        List<Course> courses = CourseRepository.getAllCourses();
        int total = Math.max(1, courses.size());
        int done = 0;
        for (Course c : courses) {
            if (gs.isCourseCompleted(c.id)) done++;
        }

        pbOverall.setMax(total);
        pbOverall.setProgress(done);

        int pct = (int) Math.round(100.0 * done / total);
        tvOverallLabel.setText("Overall progress: " + done + "/" + total + " (" + pct + "%)");
    }

    private void startHeaderAnimations() {

        ObjectAnimator pulseX = ObjectAnimator.ofFloat(imgAvatar, "scaleX", 1.0f, 1.04f, 1.0f);
        pulseX.setDuration(1600);
        pulseX.setRepeatCount(ObjectAnimator.INFINITE);
        pulseX.start();

        ObjectAnimator pulseY = ObjectAnimator.ofFloat(imgAvatar, "scaleY", 1.0f, 1.04f, 1.0f);
        pulseY.setDuration(1600);
        pulseY.setRepeatCount(ObjectAnimator.INFINITE);
        pulseY.start();

        if (viewGlow != null) {
            // Make the glow obvious and persistent
            ObjectAnimator glowAlpha = ObjectAnimator.ofFloat(viewGlow, "alpha", 0.85f, 1.0f, 0.85f);
            glowAlpha.setDuration(1200);
            glowAlpha.setRepeatCount(ObjectAnimator.INFINITE);
            glowAlpha.start();

            ObjectAnimator glowPulse = ObjectAnimator.ofFloat(viewGlow, "scaleX", 1.0f, 1.08f, 1.0f);
            glowPulse.setDuration(1200);
            glowPulse.setRepeatCount(ObjectAnimator.INFINITE);
            glowPulse.start();

            ObjectAnimator glowPulseY = ObjectAnimator.ofFloat(viewGlow, "scaleY", 1.0f, 1.08f, 1.0f);
            glowPulseY.setDuration(1200);
            glowPulseY.setRepeatCount(ObjectAnimator.INFINITE);
            glowPulseY.start();
        }


        animateIcon(btnGoProfile);
        animateIcon(btnGoPractice);
        animateIcon(btnGoScores);
        animateIcon(btnGoShop);
    }

    private void animateIcon(ImageView iv) {
        if (iv == null) return;
        ObjectAnimator bob = ObjectAnimator.ofFloat(iv, "translationY", 0f, -6f, 0f);
        bob.setDuration(1400);
        bob.setRepeatCount(ObjectAnimator.INFINITE);
        bob.start();
    }

    
    private void renderCourses(LayoutInflater inflater) {

        allCourses = CourseRepository.getAllCourses();
        if (modulesPage < 0) modulesPage = 0;
        renderModulesPage(inflater);
    }

    private void renderModulesPage(LayoutInflater inflater) {
        if (courseContainer == null) return;

        GameState gs = GameState.get();
        int total = (allCourses != null) ? allCourses.size() : 0;
        int pageCount = (int) Math.ceil(total / (double) MODULES_PER_PAGE);
        if (pageCount <= 0) pageCount = 1;

        if (modulesPage >= pageCount) modulesPage = pageCount - 1;


        if (tvModulesPage != null) {
            tvModulesPage.setText("Page " + (modulesPage + 1) + "/" + pageCount);
        }
        if (btnPrevModules != null) btnPrevModules.setEnabled(modulesPage > 0);
        if (btnNextModules != null) btnNextModules.setEnabled(modulesPage < pageCount - 1);

        courseContainer.removeAllViews();

        int start = modulesPage * MODULES_PER_PAGE;
        int end = Math.min(start + MODULES_PER_PAGE, total);

        for (int k = start; k < end; k++) {
            Course c = allCourses.get(k);

            View panel = inflater.inflate(R.layout.item_course_panel, courseContainer, false);

            TextView tvTitle = panel.findViewById(R.id.tvCourseTitle);
            TextView tvDesc  = panel.findViewById(R.id.tvCourseDescription);

            tvTitle.setText(c.title);
            tvDesc.setText(c.shortDesc);

            boolean completed = gs.isCourseCompleted(c.id);
            if (completed) {
                panel.setBackgroundColor(Color.parseColor("#2E7D32"));
            } else {
                panel.setBackgroundColor(Color.parseColor("#263238"));
            }

            panel.setOnClickListener(view -> openQuizForCourse(c.id));
            courseContainer.addView(panel);
        }
    }

    private void openQuizForCourse(String courseId) {
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).openProblemSetForCourse(courseId);
        }
    }
}
